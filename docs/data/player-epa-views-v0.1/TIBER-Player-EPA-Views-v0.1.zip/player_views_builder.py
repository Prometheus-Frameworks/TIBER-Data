"""Offline descriptive EPA views from one pinned nflverse player-week CSV."""
import csv, hashlib, json, math, sys
from pathlib import Path

EXPECTED_SHA256 = '27a8a464687901340e87873010b3583443619fad723db828f745f71c8086ec9e'

def numeric(value):
    if value is None or value in ('', 'NA'): return None
    result = float(value)
    if not math.isfinite(result): return None
    return result

def ratio(epa_values, counts):
    if any(v is None for v in epa_values + counts):
        return None, None, None, 'unavailable_missing_operand'
    if any(v < 0 or int(v) != v for v in counts):
        raise ValueError('Invalid denominator count')
    total, count = math.fsum(epa_values), sum(counts)
    if count == 0: return total, int(count), None, 'unavailable_zero_denominator'
    return total, int(count), total / count, 'available_source_aggregate'

def build(source_path, output_directory):
    data = Path(source_path).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != EXPECTED_SHA256: raise ValueError('Source digest differs from pinned snapshot')
    rows = list(csv.DictReader(data.decode('utf-8').splitlines()))
    keys = [(r['season'], r['season_type'], r['week'], r['game_id'], r['team'], r['player_id']) for r in rows]
    if len(set(keys)) != len(keys): raise ValueError('Duplicate player-game source keys')
    if any(r['season'] != '2026' or r['season_type'] != 'REG' or int(r['week']) not in range(1, 5) for r in rows):
        raise ValueError('Unexpected population')
    out = Path(output_directory); out.mkdir(parents=True, exist_ok=True)
    definitions = [('rb_epa_per_carry', 'carries', 'rushing_epa'),
                   ('receiver_epa_per_target', 'targets', 'receiving_epa'),
                   ('qb_epa_per_dropback', None, None)]
    outputs = {}
    for metric, count_field, epa_field in definitions:
        if metric == 'rb_epa_per_carry': selected = [r for r in rows if r['position'] == 'RB']
        elif metric == 'receiver_epa_per_target':
            selected = [r for r in rows if r['position'] in ('RB', 'WR', 'TE') or (numeric(r['targets']) or 0) > 0]
        else: selected = [r for r in rows if r['position'] == 'QB']
        if any(not r['player_id'] for r in selected): raise ValueError('Unresolved selected player identity')
        records = []
        groups = {}
        for r in selected:
            groups.setdefault((r['player_id'], r['team']), []).append(r)
        for grain in ('player_game', 'player_team_observed_window'):
            populations = [[r] for r in selected] if grain == 'player_game' else list(groups.values())
            for pop in populations:
                first = pop[0]
                record = {'metric_id': metric, 'definition_version': '0.1.0', 'grain': grain,
                          'player_id': first['player_id'], 'display_name': first['player_display_name'],
                          'team': first['team'], 'positions_observed': sorted(set(r['position'] for r in pop)),
                          'season': 2026, 'season_type': 'REG', 'requested_weeks': [1,2,3,4],
                          'observed_weeks': sorted(set(int(r['week']) for r in pop)),
                          'game_ids': sorted(set(r['game_id'] for r in pop)),
                          'source_row_count': len(pop), 'source_sha256': digest,
                          'source_release_updated_at': '2026-10-05T12:33:41Z',
                          'coverage_status': 'observed_rows_only_partial_week4',
                          'source_purpose_status': 'offline_prototype_only_not_general_admission',
                          'game_finality': 'unknown', 'full_week_final': False,
                          'units': 'EPA/carry' if metric == 'rb_epa_per_carry' else 'EPA/target' if count_field else 'EPA/dropback'}
                if count_field:
                    epa, count, rate, status = ratio([numeric(r[epa_field]) for r in pop], [numeric(r[count_field]) for r in pop])
                    record.update(epa_total=epa, denominator_count=count, value=rate, status=status,
                                  missing_epa_rows=sum(numeric(r[epa_field]) is None for r in pop),
                                  missing_denominator_rows=sum(numeric(r[count_field]) is None for r in pop))
                else:
                    record.update(epa_total=None, denominator_count=None, value=None,
                                  status='unavailable_full_dropback_population_not_supplied',
                                  missing_dependencies=['matching play-level EPA across throws sacks and scrambles',
                                                        'matching eligible and EPA-covered dropback count'],
                                  supplied_context={'passing_epa': math.fsum(numeric(r['passing_epa']) or 0 for r in pop) if all(numeric(r['passing_epa']) is not None for r in pop) else None,
                                                    'attempts': sum(int(r['attempts']) for r in pop),
                                                    'sacks_suffered': sum(int(r['sacks_suffered']) for r in pop)})
                records.append(record)
        outputs[metric] = records
        (out / (metric + '.json')).write_text(json.dumps(records, indent=2) + '\n')
    return outputs

if __name__ == '__main__':
    results = build(sys.argv[1], sys.argv[2])
    print(json.dumps({k: {'rows': len(v), 'status_counts': {s: sum(r['status'] == s for r in v) for s in sorted(set(r['status'] for r in v))}} for k, v in results.items()}, indent=2))
