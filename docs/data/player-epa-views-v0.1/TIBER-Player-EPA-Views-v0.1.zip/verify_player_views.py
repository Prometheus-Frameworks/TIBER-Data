import json, math, tempfile
from pathlib import Path
from player_views_builder import ratio, build

assert ratio([2.0, -1.0], [10, 20]) == (1.0, 30, 1.0 / 30, 'available_source_aggregate')
assert ratio([0.0], [1]) == (0.0, 1, 0.0, 'available_source_aggregate')
assert ratio([None], [10])[3] == 'unavailable_missing_operand'
assert ratio([0.0], [0])[2:] == (None, 'unavailable_zero_denominator')
try:
    ratio([1.0], [-1])
    raise AssertionError('negative denominator accepted')
except ValueError:
    pass
with tempfile.TemporaryDirectory() as d:
    wrong = Path(d) / 'wrong.csv'; wrong.write_text('different snapshot')
    try:
        build(wrong, Path(d) / 'output')
        raise AssertionError('changed digest accepted')
    except ValueError:
        pass
    output = build('nflverse-current.csv', Path(d) / 'output')
    assert all(r['value'] is None and r['denominator_count'] is None for r in output['qb_epa_per_dropback'])
    cook = next(r for r in output['rb_epa_per_carry'] if r['display_name'] == 'James Cook' and r['grain'] == 'player_team_observed_window')
    assert cook['denominator_count'] == 70
    assert math.isclose(cook['epa_total'], 9.175279625109395)
    assert math.isclose(cook['value'], 0.1310754232158485)
    for metric, records in output.items():
        expected = json.loads((Path('player-views') / (metric + '.json')).read_text())
        assert records == expected
print('PASS: weighted aggregation, real zero, missing operand, zero denominator, invalid count, changed source, QB unavailable, Cook witness and output reproduction')
