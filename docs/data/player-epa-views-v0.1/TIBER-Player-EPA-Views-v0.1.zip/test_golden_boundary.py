"""Regression: verification detects builder drift without rewriting goldens."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


class GoldenBoundaryTest(unittest.TestCase):
    def test_builder_drift_fails_and_goldens_remain_untouched(self):
        package = Path(__file__).resolve().parent
        with tempfile.TemporaryDirectory() as directory:
            sandbox = Path(directory)
            for name in ('player_views_builder.py', 'verify_player_views.py',
                         'nflverse-current.csv', 'package-manifest.json'):
                shutil.copy2(package / name, sandbox / name)
            shutil.copytree(package / 'player-views', sandbox / 'player-views')
            goldens = sorted((sandbox / 'player-views').glob('*.json'))
            before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in goldens}
            clean = subprocess.run([sys.executable, 'verify_player_views.py'],
                                   cwd=sandbox, capture_output=True, text=True)
            self.assertEqual(clean.returncode, 0, clean.stderr)
            builder = sandbox / 'player_views_builder.py'
            original = builder.read_text()
            needle = "'coverage_status': 'observed_rows_only_partial_week4'"
            self.assertEqual(original.count(needle), 1)
            builder.write_text(original.replace(needle, "'coverage_status': 'complete_week4'"))
            # The documented separate-output reproduction cannot refresh the oracle.
            reproduced = subprocess.run(
                [sys.executable, 'player_views_builder.py', 'nflverse-current.csv',
                 str(sandbox / 'reproduced')], cwd=sandbox, capture_output=True, text=True)
            self.assertEqual(reproduced.returncode, 0, reproduced.stderr)
            drifted = subprocess.run([sys.executable, 'verify_player_views.py'],
                                     cwd=sandbox, capture_output=True, text=True)
            self.assertNotEqual(drifted.returncode, 0)
            self.assertIn('Golden mismatch', drifted.stderr)
            self.assertEqual(before, {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                      for p in goldens})
            # Even accidental overwrite of a golden is caught against manifest custody.
            golden = goldens[0]
            records = json.loads(golden.read_text())
            records[0]['coverage_status'] = 'complete_week4'
            golden.write_text(json.dumps(records))
            overwritten = subprocess.run([sys.executable, 'verify_player_views.py'],
                                         cwd=sandbox, capture_output=True, text=True)
            self.assertNotEqual(overwritten.returncode, 0)
            self.assertIn('Golden digest mismatch', overwritten.stderr)


if __name__ == '__main__':
    unittest.main()
